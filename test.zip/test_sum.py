def test_sum():
    assert sum([4, 3, 2]) == 9

if __name__ == "__main__":
    test_sum()
    print("Everything passed")