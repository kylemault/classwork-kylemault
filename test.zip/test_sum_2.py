def test_sum():
    assert sum([4, 3, 2]) == 9

def test_sum_tuple():
    assert sum((3, 2, 1)) == 6

if __name__ == "__main__":
    test_sum()
    test_sum_tuple()
    print("passed")