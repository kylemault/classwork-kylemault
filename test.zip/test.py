import unittest

from my_sum import sum


class Test(unittest.TestCase):
    def test_list_int(self):
        data = [4, 3, 2]
        result = sum(data)
        self.assertEqual(result, 9)

if __name__ == '__main__':
    unittest.main()