import unittest
class Test(unittest.TestCase):

    def test_sum(self):
        self.assertEqual(sum([4, 3, 2]), 9)

    def test_sum_tuple(self):
        self.assertEqual(sum((3, 2, 1)), 6)

if __name__ == '__main__':
    unittest.main()